
#include <stdio.h>
#include <math.h>
#define PI 3.1415926

int main()
{
	int x,y;
	printf("������x(int):");
	scanf("%d",&x);
	if (x >= 1)
	{
		if (x < 10)
		{
			y = 2 * x - 1;
		}
		else 
		{
			y = 3 * x - 11;
		}
	}
	else
	{
		y = x;
	}
	printf("y=%d",y);
	for(;1;){}
	return 0;
}
