#include <stdio.h>
#include <math.h>
#define PI 3.1415926

int main()
{
	double x,y;
	printf("������x(double):");
	scanf("%lf",&x);
	if (x < 0)
	{
		y = fabs(x) + sin(10 / PI * 180);
	}
	else if (x < 4)
	{
		y = x * x + sqrt(x);
	}
	else
	{
		y = x / 4 + 17;
	}
	printf("y=%lf",y);
	for(;1;){}
	return 0;
}
