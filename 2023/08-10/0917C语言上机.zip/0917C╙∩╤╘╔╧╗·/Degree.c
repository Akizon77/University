#include <stdio.h>
#include <math.h>
#define PI 3.1415926

int main()
{
	double num,degree,mins,secs;
	printf("�����뻡��:");
	scanf("%lf",&num);
	degree = num / PI * 180;
	mins = fmod(degree,1.0) * 60;
	secs = fmod(mins,1.0) *60;
	printf("%d��%d��%d��",(int)degree,(int)mins,(int)secs);
	for (;1;){}
	return 0;
}